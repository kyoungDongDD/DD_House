package com.ssafy.happyhouse.model.dto;

public class PollutionMgrInfo {

	/* 업체(시설)명 */
	private String name; // <WRKP_NM>
	/* 인허가번호 */
	private String no; // <AVP_PERM_MGT_NO>///이부분
	/* 업종코드 */
	private String upjong_code; // <AVP_PERM_MGT_NO>
	/* 업종명 */
	private String upjong_name; // <UPCH_COB_NM>
	/* 지도점검일자 */
	private String cob_name; // <DRT_INSP_YMD>
	/* 점검기관 */
	private String team_code; // <ORG_AND_TEAM_CODE>
	/* 점검기관명 */
	private String team_name; // <SF_TEAM_NM>
	/* 지도점검구분 */
	private String se_name; // <DRT_INSP_SE_NM>
	/* 처분대상여부 */
	private String yn; // <DISPO_TGT_YN>
	/* 점검사항 */
	private String item; // <DRT_INSP_ITEM>
	/* 점검결과 */
	private String dtl; // <DRT_INSP_RT_DTL>
	/* 소재지도로명주소 */
	private String naddr; // <WRKP_NADDR>
	/* 소재지주소 */
	private String addr; // <WRKP_ADDR>
	
	
	/*** Constructor ***/
	public PollutionMgrInfo() {}
	public PollutionMgrInfo(String no) {
		this.no = no;
	}
	
	
	/*** Methods ***/
	
	@Override
	public String toString() {
		return "PollutionMgrInfo [name=" + name + ", no=" + no + ", naddr=" + naddr + ", addr=" + addr + "]";
	}
	
	/*** Getter & Setter ***/
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getNo() {
		return no;
	}
	public void setNo(String no) {
		this.no = no;
	}
	public String getUpjong_code() {
		return upjong_code;
	}
	public void setUpjong_code(String upjong_code) {
		this.upjong_code = upjong_code;
	}
	public String getUpjong_name() {
		return upjong_name;
	}
	public void setUpjong_name(String upjong_name) {
		this.upjong_name = upjong_name;
	}
	public String getCob_name() {
		return cob_name;
	}
	public void setCob_name(String cob_name) {
		this.cob_name = cob_name;
	}
	public String getTeam_code() {
		return team_code;
	}
	public void setTeam_code(String team_code) {
		this.team_code = team_code;
	}
	public String getTeam_name() {
		return team_name;
	}
	public void setTeam_name(String team_name) {
		this.team_name = team_name;
	}
	public String getSe_name() {
		return se_name;
	}
	public void setSe_name(String se_name) {
		this.se_name = se_name;
	}
	public String getYn() {
		return yn;
	}
	public void setYn(String yn) {
		this.yn = yn;
	}
	public String getItem() {
		return item;
	}
	public void setItem(String item) {
		this.item = item;
	}
	public String getDtl() {
		return dtl;
	}
	public void setDtl(String dtl) {
		this.dtl = dtl;
	}
	public String getNaddr() {
		return naddr;
	}
	public void setNaddr(String naddr) {
		this.naddr = naddr;
	}
	public String getAddr() {
		return addr;
	}
	public void setAddr(String addr) {
		this.addr = addr;
	}
	
	
}
