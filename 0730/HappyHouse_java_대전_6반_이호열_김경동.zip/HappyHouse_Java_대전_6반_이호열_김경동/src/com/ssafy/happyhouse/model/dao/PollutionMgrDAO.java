package com.ssafy.happyhouse.model.dao;

import java.util.List;

import com.ssafy.happyhouse.model.dto.PollutionMgrInfo;

public interface PollutionMgrDAO {

	public void loadData();
	
	public List<PollutionMgrInfo> getData();
}
