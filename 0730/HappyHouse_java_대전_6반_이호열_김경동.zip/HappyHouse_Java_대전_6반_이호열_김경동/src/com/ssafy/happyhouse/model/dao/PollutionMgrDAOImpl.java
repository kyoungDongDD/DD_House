package com.ssafy.happyhouse.model.dao;

import java.util.List;

import com.ssafy.happyhouse.model.dto.PollutionMgrInfo;
import com.ssafy.happyhouse.util.pollutionSaxParser;

public class PollutionMgrDAOImpl implements PollutionMgrDAO {

	/*** Variables ***/
	List<PollutionMgrInfo> data;
	
	
	/*** Constructor ***/
	public PollutionMgrDAOImpl() {
		loadData();
	}
	
	
	/*** Methods ***/
	
	@Override
	public void loadData() {
		pollutionSaxParser parser = new pollutionSaxParser();
		data = parser.getData();
		
	}
	
	@Override
	public List<PollutionMgrInfo> getData() {
		return data;
	}
}
