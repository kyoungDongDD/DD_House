package com.ssafy.happyhouse.view;

import java.awt.BorderLayout;
import java.util.List;

import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import com.ssafy.happyhouse.model.dao.PollutionMgrDAO;
import com.ssafy.happyhouse.model.dao.PollutionMgrDAOImpl;
import com.ssafy.happyhouse.model.dto.PollutionMgrInfo;

public class PollutionMgrInfoView {

	/*** Variables ***/
	private JFrame frame;
	
	// Components
	JTable table;
	
	// table의 데이터를 관리하는 객체
	DefaultTableModel model;
	
	
	/*** Constructor ***/
	public PollutionMgrInfoView() {
		frame = new JFrame("Environment Management Information");
		
		setMain();
		
		frame.setSize(650, 500);
		frame.setResizable(true);
	}
	
	
	/*** Methods ***/
	
	public void setMain() {
		table = new JTable();
		String[] headers = {"업체(시설)명", "인허가번호", "소재지도로명주소", "소재지주소"};
		model = (DefaultTableModel)table.getModel();
		model.setColumnIdentifiers(headers);
		
		
		frame.add(new JScrollPane(table), BorderLayout.CENTER);
		
	}
	
	public void show(String dong) {
		setMain();
		frame.setVisible(true);
		
		PollutionMgrDAO dao = new PollutionMgrDAOImpl();
		List<PollutionMgrInfo> list = dao.getData();
		
		for (PollutionMgrInfo data : list) {
			System.out.println(data);
			if (data.getNaddr().contains(dong) || data.getAddr().contains(dong)) {
				model.addRow(new Object[] {
						data.getName(), data.getNo(), data.getNaddr(), data.getAddr()
						
				});
			}
			
		}
		
	}
	
	
	
	/* ######### Main ########## */
//	public static void main(String[] args) {
//		PollutionMgrInfoView view = new PollutionMgrInfoView();
//	}
}
