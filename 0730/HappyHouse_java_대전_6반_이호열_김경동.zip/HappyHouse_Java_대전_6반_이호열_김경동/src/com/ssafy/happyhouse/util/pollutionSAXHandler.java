package com.ssafy.happyhouse.util;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.xml.sax.Attributes;
import org.xml.sax.helpers.DefaultHandler;

import com.ssafy.happyhouse.model.dto.PollutionMgrInfo;

public class pollutionSAXHandler extends DefaultHandler {

//	private Map<String, PollutionMgrInfo> pollution;
	private List<PollutionMgrInfo> pollution;
	private PollutionMgrInfo poll;
	private String temp;

	public pollutionSAXHandler() {
//		pollution = new HashMap<String, PollutionMgrInfo>();
		pollution = new ArrayList<PollutionMgrInfo>();
	}

	public void startElement(String uri, String localName, String qName, Attributes att) {
		if (qName.equals("row")) {
			poll = new PollutionMgrInfo(); //

		}
	}

	public void endElement(String uri, String localName, String qName) {
		if (qName.equals("WRKP_NM")) { // 이름이 같으면
			poll.setName(temp.trim());
		} else if (qName.equals("APV_PERM_MGT_NO")) {
			poll.setNo(temp.trim());
		} else if (qName.equals("WRKP_NADDR")) {
			poll.setNaddr(temp.trim());
		} else if (qName.equals("WRKP_ADDR")) {
			poll.setAddr(temp);
		} else if (qName.equals("row")) { // missed this!
			pollution.add(poll);
			poll = null;
		}
	}

	public void characters(char[] ch, int start, int length) {
		temp = new String(ch, start, length);
	}

//	public Map<String, PollutionMgrInfo> getpollution() {
//		return pollution;
//	}
	public List<PollutionMgrInfo> getPollution() {
		return pollution;
	}

//	public void setpollution(Map<String, PollutionMgrInfo> pollution) {
//		this.pollution = pollution;
//	}

//	public Map<String, PollutionMgrInfo> getPollutionInfo() {
//		// TODO Auto-generated method stub
//		return pollution;
//	}
	public List<PollutionMgrInfo> getPollutionInfo() {
		return pollution;
	}
}
