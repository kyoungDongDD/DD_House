package com.ssafy.happyhouse.util;

import java.util.List;
import java.util.Map;

import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import com.ssafy.happyhouse.model.dto.HouseInfo;
import com.ssafy.happyhouse.model.dto.PollutionMgrInfo;

public class pollutionSaxParser {
	private Map<String, List<PollutionMgrInfo>> polls;
//	private Map<String, PollutionMgrInfo> pollutionInfo;
	private List<PollutionMgrInfo> pollutionInfo;
	private int size;
	public static int no;

	public pollutionSaxParser() {
		loadData();
	}

	private void loadData() {

		SAXParserFactory factory = SAXParserFactory.newInstance();
		String PollutionMgrinfoURL = "http://openapi.jongno.go.kr:8088/4c63456c467873723437724c626165/xml/JongnoListEnvGuideCheck/1/100";

		try {
			SAXParser parser = factory.newSAXParser();
			pollutionSAXHandler handler = new pollutionSAXHandler();

			parser.parse(PollutionMgrinfoURL, handler);
//<<<<<<< HEAD
//			pollutionInfo = handler.getPollutionInfo();	
//		
//	}catch(Exception e){
//		e.printStackTrace();
//=======
			pollutionInfo = handler.getPollutionInfo();

		} catch (Exception e) {
			e.printStackTrace();
 
		}
	}
	
	public List<PollutionMgrInfo> getData() {
		return pollutionInfo;
	}
}
