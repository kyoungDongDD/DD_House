package day3hw;

public class Product {
	
	protected String Num;//제품번호 제품이름 가격 수량
	protected String Name;
	protected int Price;
	protected int Count;
	
	public Product() {}
	
	public Product(String Num,String Name,int Price,int count) {
	this.Num=Num;
	this.Name=Name;
	this.Price=Price;
	this.Count=Count;
	
	}
	public String getNum() {
		return Num;
		
	}
		public String getNum(String Num) {
		return Num;
	}
		@Override
		public String toString() {
			return "Product [Num=" + Num + ", Name=" + Name + ", Price=" + Price + ", Count=" + Count + "]";
		}
		
}