package day3hw;

import java.util.Arrays;

public class ProductManager {
int max_size=100;
	
	Product[] pdArray = new Product[max_size];
	
	//현재 프로덕트 갯수
	int Pnum;
	
	public void addOther(Product pd1) {		
		if(Pnum<max_size) {pdArray[Pnum++]=pd1;}		
	}	
	public void addFrez(Product pd1) {		
		if(Pnum<max_size) {pdArray[Pnum++]=pd1;}		
	}
	public void addTV(Product pd1) {		
		if(Pnum<max_size) {pdArray[Pnum++]=pd1;}		
	}
	
	public void remove(String num) {	//매서드에서 받을값 Pnum 
		
		int pointer=0;
		for(int i =0;i<Pnum;i++) {
		if(pdArray[i].getNum().equals(Pnum)) {  // product[i].getPnum()=="Pnum" 같은 녀
			pdArray[i]=null;
			Pnum--;
			pointer=1;
		}
		if(pointer==1) {
			pdArray[i]=pdArray[i+1];
		}
		}
	}
	public Product[] getlist() {
		
		return pdArray;		
	}
	public Product serchByPnum(String num)	{		
		for(int i =0;i<Pnum;i++) {
			if(pdArray[i].getNum().equals(num)) {
				
				return pdArray[i];
			}			
		}
		return null;
	}

}
