package day3hw;

import java.util.Arrays;
import java.util.Scanner;



public class ProductTest {
	
	public static void main(String[] args) {
		
		TV tv1=new TV();
		TV tv2=new TV("r873","큐올레드TV",230000,50,30,"QLED");//String Num,String Name,int Price,int Count,int Inch,String Disp_type
		Refrigerator R1=new Refrigerator("r873","삼성비스포크",230000,50,100);
		
		System.out.println(tv1.toString());
		System.out.println(tv2.toString());
		System.out.println(R1.toString());
		// TODO Auto-generated method stub
		/*
		ProductManager pdArray1= new ProductManager();
		pdArray1.addFrez(new Product("r873","삼성비스포크",230000,50));
		pdArray1.addOther(new Product("s154","엘지 청소기",20000,12));
		pdArray1.addTV(new Product("p223","큐올레드TV",4000000,200));
		*/
}
}