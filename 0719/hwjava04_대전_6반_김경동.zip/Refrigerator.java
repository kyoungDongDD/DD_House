package day3hw;

public class Refrigerator extends Product {
		
		int Volume;
			
		public Refrigerator() {}
		public Refrigerator(String Num,String Name,int Price,int Count,int Volume) {			
			this.Num=Num;
			this.Name=Name;
			this.Price=Price;
			this.Count=Count;
			this.Volume=Volume;
			
		}
		@Override
		public String toString() {
			return "Refrigerator [Volume=" + Volume + ", Num=" + Num + ", Name=" + Name + ", Price=" + Price
					+ ", Count=" + Count + "]";
		}
		
	}

