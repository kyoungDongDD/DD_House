package day3hw;

public class TV extends Product {
	int Inch;
	String Disp_type;

	public TV() {}
	public TV(String Num,String Name,int Price,int Count,int Inch,String Disp_type) {
		this.Num=Num;
		this.Name=Name;
		this.Price=Price;
		this.Count=Count;
		this.Inch=Inch;
		this.Disp_type=Disp_type;
	}
	@Override
	public String toString() {
		return "TV [Inch=" + Inch + ", Disp_type=" + Disp_type + ", Num=" + Num + ", Name=" + Name + ", Price=" + Price
				+ ", Count=" + Count + "]";
	}
	
}
