package com.ssafy.ws01.step3;

import java.util.Scanner;

public class hw3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 Scanner sc= new Scanner(System.in);
		 int hight=sc.nextInt();
		 int weight=sc.nextInt();
		 
		 int cal=(100+weight)-hight;
		 System.out.println("비만수치는 "+cal+"입니다");
		 if(cal>0) {
			 System.out.println("당신은 비만이군요");			 
		 }
		 else {
			 System.out.println("당신은 비만이 아니군요");
		 }		
	}
}
