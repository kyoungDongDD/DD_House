package com.java.first;

public class CircleArea {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//반지름 5이상 원의 넓이를 구하는 프로그램
		int r=5; //반지름
		double s=Math.PI*Math.pow(r, 2);
		System.out.println("넓이는 : "+ s);
	}

}
