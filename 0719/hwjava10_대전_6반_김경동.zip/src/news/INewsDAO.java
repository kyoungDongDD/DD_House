package news;

import java.util.List;

public interface INewsDAO {
	 List<news> getNewsList(String url);
	 news serch(int index);	

}
