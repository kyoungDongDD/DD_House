package news;

public class news_SaxHaddler {

}
