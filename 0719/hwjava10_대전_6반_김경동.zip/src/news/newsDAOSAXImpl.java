package news;

import java.util.List;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

import java.io.File;
import java.util.ArrayList;

public class newsDAOSAXImpl implements INewsDAO {
	
	
	static List<news>list= new ArrayList<news>(); 
	//파싱한 멤버 객체
	
	
	@Override
	public List<news> getNewsList(String url) {
		// TODO Auto-generated method stub
		
		try {
				SAXParserFactory factory  = SAXParserFactory.newInstance();
				SAXParser parser = factory.newSAXParser();	
				
				SAXHandler handler = new SAXHandler();
				parser.parse(url, handler);
				
				
		} catch (Exception e) {
			// TODO Auto-generated catch block			
			e.printStackTrace();
		} 
		
		return list;
	}

	@Override
	public news serch(int index) {
		// TODO Auto-generated method stub
		return null;
	}
}
