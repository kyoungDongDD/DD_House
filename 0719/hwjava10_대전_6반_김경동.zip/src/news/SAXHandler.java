package news;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

public class SAXHandler extends DefaultHandler {
	
	private news current;
	//character 메소드에서 저장할 문자열 변수
	private String content;
	
	
	public void startElement(String uri, String localName, String qName, Attributes att)throws SAXException {
		
		//시작 태그를 만났을 때 발생하는 이벤트
		//member태그에 해당하는 사항을 불러온다
		
		if(qName.equals("item")) {
			current = new news();
			
		}
	}
	public void characters(char[] ch, int start, int length) throws SAXException {
		//태그와 태그 사이의 내용을 처리
		
		content = new String(ch,start,length);
		
		
	}
	public void endElement(String uri, String localName, String qName)throws SAXException {
		//끝 태그를 만났을 때,
		//  각각 끝태그를 만나면 Current 객체에 셋팅
		if(current!=null) {
			
			if(qName.equals("title")) {
				current.setTitle(this.content);
				
			}
			else if(qName.equals("description")) {
				current.setDesc(this.content);
			}
			
			else if(qName.equals("item")) {
				newsDAOSAXImpl.list.add(current);
				
				current=null;
				
			}
		}
		
	}
}
