import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class swea_7465_미완 { //테케 다 잘나오는데 정답이 안나오네요 어디가 잘못된지 모르겠어요 ㅠㅜㅠ
	static int N;
	static int M;
	static int []parents;
	
	private static void make(BufferedReader bf,StringTokenizer st) throws IOException {
		st= new StringTokenizer(bf.readLine());
		 N=Integer.parseInt(st.nextToken());
		 M=Integer.parseInt(st.nextToken());
		 parents = new int[N+1];		 
		for(int i=1;i<=N;i++) parents[i]=i;
	}
	
	private static int find(int a) {
		if(a==parents[a]) return a;
		return parents[a] = find(parents[a]);
	}
	
	private static void union(int a,int b) {
		int aRoot = find(a);
		int bRoot = find(b);
		if(aRoot==bRoot)return;
		
		parents[bRoot]= aRoot;		
	}
	
	private static void makeUnioin(BufferedReader bf,StringTokenizer st) throws IOException {
		for(int i=0;i<M;i++) {
			 st= new StringTokenizer(bf.readLine());			 
			 int num1=Integer.parseInt(st.nextToken());
			 int num2=Integer.parseInt(st.nextToken());			 
			 union(num1,num2);			 
		}
	}
	
	private static void cal(int []nums) {
		int aParent=0;
		int count=0;		
		boolean flag=false;
		for(int i=1;i<=N;i++) {
			flag=false;
			aParent= find(i);
			
			for(int j=0;j<count;j++) {
				if(nums[j]==aParent) { // 
					flag=true;
				}				
			}		 
//			System.out.println(i+" / "+flag +" / "+aParent);
			
			
			if(flag==false)	{				
				nums[count++]=aParent;
				}
		}
		System.out.println(count);
	}
	public static void main(String args[]) throws IOException {
		BufferedReader bf= new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st= new StringTokenizer(bf.readLine());
		int T=Integer.parseInt(st.nextToken());
		for(int z=1;z<=T;z++) {				
			System.out.print("#"+z+" ");
			make(bf,st);  			//입력을 받아 parents 배열을 만듬
			int[] nums=new int[N+1];
			makeUnioin(bf,st);		//입력을 받아 0일경우 union시키고 1일경우 계산.
			cal(nums);
			System.out.println();
		}
	}
}