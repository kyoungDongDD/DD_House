import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;



public class beakJun_1992 {
	
	public static void cal(int r,int c,int N,char[][]map) {
		char temp=map[r][c];
		boolean changed=false;
		if(N==1) {
			System.out.print(map[r][c]);
			changed=false;
			return;
		}
		for(int i=c;i<c+N;i++) {			
			for(int j=r;j<r+N;j++) {
				if(map[j][i]!=temp) {					
					System.out.print("(");
					cal(r,c,N/2,map);					
					cal(r,c+N/2,N/2,map);
					cal(r+N/2,c,N/2,map);
					cal(r+N/2,c+N/2,N/2,map);
					System.out.print(")");
					changed=true;
					return;
				}
			}
		}
		if(changed==false)System.out.print(map[r][c]);
	}

	public static void main(String[] args) throws NumberFormatException, IOException {
		// TODO Auto-generated method stub
		BufferedReader bf= new BufferedReader(new InputStreamReader(System.in));
		int N=Integer.parseInt(bf.readLine());
		char[][]map= new char[N][N];
		for(int i=0;i<N;i++) {
			map[i]=bf.readLine().toCharArray();
		}			
		cal(0,0,N,map);
	}
}