import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.LinkedList;

public class Main {//시간초과가 납니다 ㅠㅜㅠㅜㅠㅜ 로직은 확실한데 시간초과 잡는법을 모르겟습니다아아아아아
	static int sum=0;
	public static void cal(int r, int c,int count,String[] CR,LinkedList<Character> alpa,char [][]map) {
		int delta[][]= {{0,-1},{1,0},{0,1},{-1,0}};
		boolean stop=false;
		for(int i=0;i<4;i++) {
			stop=false;
			int rx=r+delta[i][0];
			int ry=c+delta[i][1];
			if(rx>=0&&ry>=0&&rx<Integer.parseInt(CR[1])&&ry<Integer.parseInt(CR[0])) {				
				for(int j=0;j<alpa.size();j++) {
					if(map[ry][rx]==alpa.get(j)) {
						stop=true;
						break;
					}
				}
				if(stop!=true) {
					count++;
					alpa.add(map[ry][rx]);
					cal(rx,ry,count,CR,alpa,map);
					count--;
					alpa.removeLast();					
				}				
			}
		}		
		if(stop==true) {
			sum=Math.max(sum, count);
			return;
		}
	}
	public static void main(String[] args) throws IOException {		
		BufferedReader bf = new BufferedReader(new InputStreamReader(System.in));
		String []CR=bf.readLine().split(" ");
		char[][]map = new char[Integer.parseInt(CR[0])][Integer.parseInt(CR[1])];
		LinkedList<Character> alpa= new LinkedList<Character>();
		int count=1;
		for(int i=0;i<Integer.parseInt(CR[0]);i++) {
			map[i]=bf.readLine().toCharArray();
		}
		alpa.add(map[0][0]);		
		cal(0,0,count,CR,alpa,map);		
		System.out.println(sum);		
	}
}
