import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class swea_1247 {	// 순열로 줄세워서 풀어버리기

	public static void main(String[] args) throws NumberFormatException, IOException {
		// TODO Auto-generated method stub
		BufferedReader bf= new BufferedReader(new InputStreamReader(System.in));
		int T=Integer.parseInt(bf.readLine());
		int N=Integer.parseInt(bf.readLine());
		
		String[] num = bf.readLine().split(" ");
	}

}
