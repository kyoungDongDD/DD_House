import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Stack;

 

public class beakJun_2493 {
	
	public static void main(String[] args) throws IOException {	
		
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		int N=Integer.parseInt(br.readLine());		
		String k=br.readLine();		
		String[] tower=k.split(" ");		
		Stack<Integer> stack = new Stack<>(); //높이 스택
		Stack<Integer> stackNum = new Stack<>();// 번호 스택
		
		System.out.print("0 ");						//처음은 무조건 0
		stack.push(Integer.parseInt(tower[0]));		//높이 푸시
		stackNum.push(0);							//순서값 푸시
		
		for(int i=1;i<N;i++) {									
			if(Integer.parseInt(tower[i])<=stack.peek()) {	// #1. 현재 탑이 이전스택보다 작을때
				System.out.print((stackNum.peek())+1+" ");	//스택넘버 프린트(stackNUM=0부터니 +1) 			
				stack.push(Integer.parseInt(tower[i]));
				stackNum.push(i);								
			}
			else {									//#2. 현재 탑이 이전스택보다 클때
				while(true) {				
					if(stack.empty()) {					//스택 비어있나 확인 (모든 스택이 나보다 작을경우)
							stack.push(Integer.parseInt(tower[i]));
							stackNum.push(i);						
							System.out.print("0 ");
							break;
						}
					
					else if(Integer.parseInt(tower[i])<=stack.peek()) {	//스택을 지워나가다 나보다 큰 스택을 만난경우				
							System.out.print((stackNum.peek())+1+" ");  //해당스택의 넘버 출력
							stack.push(Integer.parseInt(tower[i]));		//이번 타워 높이 푸시
							stackNum.push(i);							//이번 타워 순서 푸시
							break;
						}
					 
					else {												// 스택 각 1개씩 지움
							stack.pop();								//높이 스택 지워나감
							stackNum.pop();								//순서 스택 지워나감	
					}
				}				
			}			
		}	
	}
}
