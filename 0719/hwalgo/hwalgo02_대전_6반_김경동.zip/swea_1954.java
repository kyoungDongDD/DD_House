package com.ssafy.hwalgo02;

import java.util.Scanner;
import java.io.FileInputStream;

public class swea_1954 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		int T;
		T=sc.nextInt();
		for(int test_case = 1; test_case <= T; test_case++)
		{
			int N=sc.nextInt();
			int [][]Dalpaing=new int[N][N];
			
			
			int count=0;
			int num=1;
			while(num<=N*N) {
				int x=count;
				int y=count;
				
				for(int i=x;i<N-count;i++) {//우
					Dalpaing[i][y]=num;
					num++;
					x=i;
					
				}
				for(int j=y+1;j<N-count;j++) {	//하
					Dalpaing[x][j]=num;
					num++;
					y=j;
				}	
				for(int i=x-1;i>=count;i--) {//좌
					Dalpaing[i][y]=num;
					num++;
					x=i;
				}
				
				for(int j=y-1;j>count;j--) {		//상
					Dalpaing[x][j]=num;
					num++;
				}	
					count++;			
			}
			System.out.println("#"+test_case);
			for(int i=0;i<N;i++) {
				for(int j=0;j<N;j++) {
					System.out.print(Dalpaing[j][i]+" ");					
				}
				System.out.println("");
			}
			
		}
	}
}