import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;
import java.util.StringTokenizer;

public class beakJun_1759 {
	public static int L, C;
	public static String[] arr;
	public static void input() throws IOException {
		BufferedReader bf = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st= new StringTokenizer(bf.readLine());
		L=Integer.parseInt(st.nextToken());
		C=Integer.parseInt(st.nextToken());
		arr=bf.readLine().split(" ");		
		Arrays.sort(arr);	
//		for(int i=0;i<arr.length;i++) System.out.print(arr[i]+" ");
	}
	
	public static boolean check(String str) { // 자음 모음 조건을 확인하는 함수
		int aeiou=0;
		int rest=0;
		for(int i=0;i<str.length();i++) {
			char temp=str.charAt(i);
			if(temp=='a'||temp=='e'||temp=='i'||temp=='o'||temp=='u') aeiou++;
			else rest++;
		}
		if(aeiou>0&&rest>1) { 	// 최소 한개의 모음과 두개의 자음 조건 만족시 true
			return true;
		}
		return false;			// 만족 못할시 false		
	}
	
	public static void dfs(int depth,String str) {	//dfs탐색
//		System.out.println(depth+" " +L);
		if(depth==L) {					//최대 깊이에서
			if(!check(str)) return;		//조건 확인 true아닐시 return
			System.out.println(str); 	//조건 만족할시 프린트			
		}
		else {
			for(int i=depth;i<C;i++) {
				if(!str.isEmpty()) { 	//빈 문자열 거름
					if(str.charAt(str.length()-1)>=arr[i].charAt(0)) //사전순서에 맞는지 확인 
						continue;
				}
				dfs(depth+1,str+arr[i]); //글자 넣고 깊이 추가
			}		
		}
	}
	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		input();
		dfs(0,"");		
	}
}
