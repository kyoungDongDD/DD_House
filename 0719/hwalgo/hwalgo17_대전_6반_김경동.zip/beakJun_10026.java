import java.util.Arrays;
import java.util.Scanner;

public class beakJun_10026 {
	static int[][] arr;
	static boolean[][] visited;
	static int[] dx = {0,1,0,-1};
	static int[] dy = {1,0,-1,0};
	static int n, count1 = 0, count2 = 0;
	//		count1= 일반인이 본 구역 수	count2=색약이 본 구역수  
	
	static void dfs1(int x, int y){  //색약아닌 일반인 구역나누기
		visited[x][y] = true;
		for(int i = 0; i<4; i++){	 //델타 탐색해서 구역구함 
			int tempX = x + dx[i];
			int tempY = y + dy[i];
			
			if(tempX >= 0 && tempY >= 0 && tempX < n && tempY < n){
				if(arr[x][y] == arr[tempX][tempY] && !visited[tempX][tempY]){
					dfs1(tempX, tempY);
				}
			}
		}
	}
	static void dfs2(int x, int y){	//적록 색약 구역나누기
		visited[x][y] = true;
		for(int i = 0; i<4; i++){
			int tempX = x + dx[i];
			int tempY = y + dy[i];
			
			if(tempX >= 0 && tempY >= 0 && tempX < n && tempY < n){
				if(arr[x][y] == arr[tempX][tempY]  || arr[x][y] == arr[tempX][tempY] - 11 || arr[x][y] == arr[tempX][tempY] + 11){
					if(!visited[tempX][tempY]){
						dfs2(tempX, tempY);
					}
				}
			}
		}
	}
	public static void main(String[] args){
		Scanner sc = new Scanner(System.in);
		n = sc.nextInt(); arr = new int[n][n]; visited = new boolean[n][n];
		for(int i = 0; i<n; i++){
			String str = sc.next();
			for(int o = 0; o<n; o++){
				arr[i][o] = str.charAt(o) - 'A';
			}
		}
		for(int i = 0; i<n; i++){	//일반인 
			for(int o = 0; o<n; o++){
				if(!visited[i][o]) {
					dfs1(i,o);
					count1++;
				}
			}
		}
		for(boolean[] a : visited) Arrays.fill(a, false);
		for(int i = 0; i<n; i++){
			for(int o = 0; o<n; o++){
				if(!visited[i][o]) {
					dfs2(i,o);
					count2++;
				}
			}
		}
		System.out.println(count1 + " " + count2);
	}
}


