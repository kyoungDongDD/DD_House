package  com.ssafy.hwalgo06;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class swea_9229_미완 { // 아으..... 시간에러 잡기 너무힘들어요 ㅠㅜㅠㅜㅠ
	static int N;
	static int M;
	static int temp=-999;	//현 최대값
	static int a;	    	//사용횠수
	static int tempA;	//사용횟수 저장값

	static void powerSet(int cnt, int a, int wei[],boolean[] visit, int sum) {		
		if (cnt == N) {
		  int falseCnt = 0;
			for (int i = 0; i < N; i++) {			
				if (!visit[i]) {				
					falseCnt++;
				}
			}
			if (falseCnt != N) {			
				if (sum <= M) {					
					if(sum>temp) {						
					temp=sum;
					tempA=a;
					}
				}
			}
			return;
		}		
		visit[cnt] = true;		
		powerSet(cnt + 1, a + 1, wei,visit, sum + wei[cnt]);
		visit[cnt] = false;
		powerSet(cnt + 1, a, wei,visit, sum);
	}



	
 public static void main(String arg[]) throws NumberFormatException, IOException {
	 BufferedReader bf = new BufferedReader(new InputStreamReader(System.in));
	 int T=Integer.parseInt(bf.readLine());
	 for(int test_case=1;test_case<=T;test_case++) {
		 String []TC=bf.readLine().split(" ");
		 N=Integer.parseInt(TC[0]);					//M,N입력받음
		 M=Integer.parseInt(TC[1]);
		 String []Weight=bf.readLine().split(" ");
		 int	[]wei=new int[N];
		 boolean[]visit=new boolean[N];		 
		 for (int i = 0; i < N; i++) {
			 wei[i]=Integer.parseInt(Weight[i]);			
		 }		 
		 powerSet(0,0,wei,visit,0);
		 if(tempA>=2) {
		 System.out.println("#"+test_case+" "+temp);
		 }
		 else System.out.println("#"+test_case+" -1");
		 temp=-999;
	 }
  }
}
