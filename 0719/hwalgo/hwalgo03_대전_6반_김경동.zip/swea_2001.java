import java.util.Scanner;

class swea_2001
{
	public static void main(String args[]) throws Exception
	{		
		Scanner sc = new Scanner(System.in);
		int T;
		T=sc.nextInt();
		for(int test_case = 1; test_case <= T; test_case++)
		{
			int sum=0;
			int map=sc.nextInt();
			int wp=sc.nextInt();			
			int [][]flyMap= new int [map][map];			
			
			for(int i=0;i<map;i++) {
				for(int j=0;j<map;j++) {
					flyMap[j][i]=sc.nextInt();
				}
			}
			for(int i=0;i<=map-wp;i++) {
				for(int j=0;j<=map-wp;j++) {
					int wpX=j;
					int wpY=i;
					int sumFly=0;
					for(int p=0;p<wp;p++) {						
						wpY=i+p;
						for(int k=0;k<wp;k++) {						
							 wpX=j+k;
							 sumFly+=flyMap[wpX][wpY];						
						}					
					}
					if(sum<sumFly)sum=sumFly;
				}
			}
		}
	}
}