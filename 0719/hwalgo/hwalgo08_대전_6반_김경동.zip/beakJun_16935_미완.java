import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class beakJun_16935_미완 {
	
	public static void mode(int N,int M,int odd,int count,int R,int[][]map,int[][]Map,int [][]mapT,int [][] MapT,int[] Mode) {
		//===============================cmd 모두완료시 출력 =========================================
		if(count==R) {
			if(odd%2==0) {
				for(int i=0;i<M;i++) {			
					for(int j=0;j<N;j++) {
							System.out.print(map[j][i]+" ");	
					}
					System.out.println();
				}
			}
			else {
				for(int i=0;i<M;i++) {			
					for(int j=0;j<N;j++) {
						System.out.print(Map[j][i]+" ");	
					}
					System.out.println();
				}
			}
			return;
			}
		//===============================model: 1 =========================================
		else if(Mode[count]==1) {					
			for(int i=0;i<M;i++) {			
				for(int j=0;j<N;j++) {						
					if(odd%2==0)mapT[j][i]=map[j][i];
					else MapT[j][i]=Map[j][i];
				}
			}
			for(int i=0;i<M;i++) {			
				for(int j=0;j<N;j++) {					
					if(odd%2==0)map[j][i]=mapT[j][M-1-i];
					else Map[j][i]=MapT[j][M-1-i];//여기
				}
			}
			count++;
			mode(N,M,odd,count,R,map,Map,mapT,MapT,Mode);
		}
		//===============================model: 2 =========================================
		else if(Mode[count]==2) {				
			for(int i=0;i<M;i++) {			
				for(int j=0;j<N;j++) {
					if(odd%2==0)mapT[j][i]=map[j][i];
					else MapT[j][i]=Map[j][i];	//여기
				}
			}
			
			for(int i=0;i<M;i++) {			
				for(int j=0;j<N;j++) {			
					if(odd%2==0)map[j][i]=mapT[N-1-j][i];
					else Map[j][i]=MapT[N-1-j][i];//여기
				}
			}
			count++;
			mode(N,M,odd,count,R,map,Map,mapT,MapT,Mode);
		}
		
		//===============================model: 3 =========================================
		else if(Mode[count]==3) {												
			if(odd%2==0) {					
				for(int i=0;i<M;i++) {					
					for(int j=0;j<N;j++) {
						int p=(M-1)-i;
						int q=j;
						Map[p][q]=map[j][i];							
					}
				}				
			}			
			else if(odd%2==1){
				for(int i=0;i<M;i++) {			
					for(int j=0;j<N;j++) {
						int p=(M-1)-i;
						int q=j;	
						map[p][q]=Map[j][i];	
					}				
				}				
			}
			count++;
			odd++;
			mode(M,N,odd,count,R,map,Map,mapT,MapT,Mode);
			return;
		}
		//===============================model: 4 =========================================
		else if(Mode[count]==4) {							
								
			if(count%2==0) {				
				for(int i=0;i<M;i++) {			
					for(int j=0;j<N;j++) {
						int p=i;
						int q=(N-1)-j;					
						Map[p][q]=map[j][i];	
					}				
				}	
				count++;
				odd++;
				mode(M,N,odd,count,R,map,Map,mapT,MapT,Mode);
			}			
			else {
				for(int i=0;i<M;i++) {			
					for(int j=0;j<N;j++) {
						int p=i;
						int q=(N-1)-j;	
						map[p][q]=Map[j][i];	
					}				
				}				
				count++;
				odd++;
				mode(M,N,odd,count,R,map,Map,mapT,MapT,Mode);
			}			
			return;
		}		
		//===============================model: 5 =========================================
		else if(Mode[count]==5) {			
		
			int p=0;
			int q=0;
			for(int i=0;i<M;i++) {			
				for(int j=0;j<N;j++) {
				
					if(odd%2==0)mapT[j][i]=map[j][i];
					else MapT[j][i]=Map[j][i];
				}
			}
			for(int i=0;i<M;i++) {			
				for(int j=0;j<N;j++) {
					if(j<N/2&&i<M/2) {
						p=j+N/2;
						q=i;
					}
					else if(j>=N/2&&i<M/2) {
						p=j;
						q=i+M/2;
					}
					else if(j>=N/2&&i>=M/2) {
						p=j-N/2;
						q=i;
					}
					else if(j<N/2&&i>=M/2) {
						p=j;
						q=i-M/2;
					}					
					if(odd%2==0)map[p][q]=mapT[j][i];
					else MapT[p][q]=Map[j][i];	//여기		
				}				
			}
			count++;			
			mode(N,M,odd,count,R,map,Map,mapT,MapT,Mode);
		}
		//===============================model: 6 =========================================
		else if(Mode[count]==6) {			
			int p=0;
			int q=0;
			for(int i=0;i<M;i++) {			
				for(int j=0;j<N;j++) {
					if(odd%2==0)mapT[j][i]=map[j][i];
					else MapT[j][i]=Map[j][i];	
				}
			}
			for(int i=0;i<M;i++) {			
				for(int j=0;j<N;j++) {
					if(j<N/2&&i<M/2) {
						p=j;
						q=i+M/2;
						
					}
					else if(j>=N/2&&i<M/2) {
						p=j-N/2;
						q=i;
						
					}
					else if(j>=N/2&&i>=M/2) {
						p=j;
						q=i-M/2;
						
					}
					else if(j<N/2&&i>=M/2) {
						p=j+N/2;
						q=i;						
					}					
					if(odd%2==0)map[p][q]=mapT[j][i];
					else MapT[p][q]=Map[j][i];
					}				
				}
			count++;
			mode(N,M,odd,count,R,map,Map,mapT,MapT,Mode);
			}
		return;
		}
	
	public static void main(String[] args) throws IOException {
		BufferedReader bf= new BufferedReader(new InputStreamReader(System.in));
		String[] cmd=bf.readLine().split(" ");
		int M=Integer.parseInt(cmd[0]);
		int N=Integer.parseInt(cmd[1]);
		int R=Integer.parseInt(cmd[2]);		
		int [][] map= new int [N][M];
		int [][] mapT= new int [N][M];	//부분배열용
		int [][] Map= new int [M][N];	//돌리기용	
		int [][] MapT= new int [M][N];		
		int count=0;
		int odd=0;
		for(int i=0;i<M;i++) {						//넘버 배열넣기
			String []command = bf.readLine().split(" ");
			for(int j=0;j<N;j++) map[j][i]=Integer.parseInt(command[j]);			
		}
		String[] mode=bf.readLine().split(" ");
		int []Mode=new int[R];
		for(int i=0;i<R;i++) Mode[i]=Integer.parseInt(mode[i]);		
		mode(N,M,odd,count,R,map,Map,mapT,MapT,Mode);
	}
}