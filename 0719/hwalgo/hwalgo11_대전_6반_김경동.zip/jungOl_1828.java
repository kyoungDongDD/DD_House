import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;
import java.util.Comparator;
import java.util.StringTokenizer;

public class Main {

	public static void main(String[] args) throws NumberFormatException, IOException {
		// TODO Auto-generated method stub
		BufferedReader bf= new BufferedReader(new InputStreamReader(System.in));
		int N=Integer.parseInt(bf.readLine());
		int chemical[][]=new int [N][2];
		for(int i=0;i<N;i++) {
			StringTokenizer st= new StringTokenizer(bf.readLine());
			chemical[i][0]=Integer.parseInt(st.nextToken());
			chemical[i][1]=Integer.parseInt(st.nextToken());		
		}
		Arrays.sort(chemical,new Comparator<int[]>(){

			@Override
			public int compare(int[] o1, int[] o2) {
				// TODO Auto-generated method stub
				return Integer.compare(o1[1], o2[1]);
			}});
		int count=1;
		int spot=chemical[0][1];
		for(int i=0;i<N;i++) {
			if(spot<chemical[i][0]) {
				count++;
				spot=chemical[i][1];
			}
		}
		System.out.println(count);
	}
}
