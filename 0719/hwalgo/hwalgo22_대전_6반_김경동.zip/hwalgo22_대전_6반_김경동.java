
import java.util.Scanner;

public class jol_1681 {
	static int N;
	static int answer = Integer.MAX_VALUE;
	static boolean[] visited;
	static int[][] map;

	public static void dfs(int startX, int idx, int cost) {
		
		// 중간 비용이 정답보다 크다면 탈락.
		if ( cost >= answer) {
			return;
		}
		/// 다 골랐으면
		if ( idx == N-1) {
			// 다시 회사로 돌아오는 길이 있으면
			if ( map[startX][0] !=0 ) {
				answer = Math.min(answer, cost + map[startX][0]);
			}				
			return;	
		}			
		for( int i=1; i<N; i++) { // 0은 회사니까
			// 그쪽으로 가는 길이 있고 , 거기 방문한적 없으면
			if ( map[startX][i] != 0 && !visited[i]) { 
				visited[i] = true; // 방문처리하고
				dfs(i, idx+1, map[startX][i] + cost);
				visited[i] = false;
			}
		}				
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);

		N = sc.nextInt();
		map = new int[N][N];
		visited = new boolean[N];

		for (int i = 0; i < N; i++) {
			for (int j = 0; j < N; j++) {
				map[i][j] = sc.nextInt();
			}
		}

		// 0번 장소에서 시작해서 모든 곳 돌고, 다시 0번으로 끝나야함.
		// 1. visited 처리하기 어려우니까 0 부터 시작해서 일단 모든 곳 들리기
		// 2. 모든 곳 들린다음에 마지막으로 다시 0번 가는길 있는 경우만 체크하기
		dfs(0, 0, 0);

		System.out.println(answer);

	}
}