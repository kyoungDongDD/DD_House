package live;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class swea_4014 {
	static int [][]map;
	static int N;
	static int X;
	static int max;
	static int[] dx= {0,0,1,-1};
	static int[] dy= {-1,1,0,0};
	static boolean []tempUsed;
	public static void solve() {
		max=2*N;
		for (int i = 0; i <N ; i++) { 
			tempUsed=new boolean[N];
            for (int j = 0; j <N-1 ; j++) {            		
                if(Math.abs(map[i][j]-map[i][j+1])>1) {                	
                	max--;
                	break;
                }
                else if(Math.abs(map[i][j]-map[i][j+1])==1&&!checkR(i,j)) {

                	max--;
                	break;
                }                    
            }
        }
		
		for (int j = 0; j <N ; j++) {
			tempUsed=new boolean[N];
			for (int i = 0; i <N-1 ; i++) {        
				if(Math.abs(map[i][j]-map[i+1][j])>1) {
	
		        	max--;
		        	break;
		        }
		        else if(Math.abs(map[i][j]-map[i+1][j])==1&&!checkC(i,j)) {

		        	max--;
		        	break;
		        }            
			}
		}
	}
	public static boolean checkR(int i,int j) { // 가로줄
		
		if(map[i][j]-map[i][j+1]>0) {	//내리막 오른쪽으로 봐 i,j+1기준
			int rx=j+1;
			int ry=i;
			if(tempUsed[rx]) return false;
			else tempUsed[rx]=true;
			for(int p=0;p<X-1;p++) {				
			
				rx+=dx[2];
				ry+=dy[2];
				if(rx>=N||tempUsed[rx]||
						map[i][j+1]!=map[ry][rx]) {
					
					return false;					
				}
				tempUsed[rx]=true;								
			}
		}
		else {	//오르막 왼쪽으로봐 i,j기준
			int rx=j;
			int ry=i;
			if(tempUsed[rx]) return false;
			else tempUsed[rx]=true;
			for(int p=0;p<X-1;p++) {
			
				rx+=dx[3];
				ry+=dy[3];
				if(rx<0||tempUsed[rx]||map[i][j]!=map[ry][rx]) {
					
					return false;					
				}
				tempUsed[rx]=true;
			}
		}
		return true;
	}
	public static boolean checkC(int i,int j) { // 세로줄
		if(map[i][j]-map[i+1][j]>0) {	//내리막 아래쪽으로 봐 i+1,j기준
			int rx=j;
			int ry=i+1;
			if(tempUsed[ry]) return false;
			else tempUsed[ry]=true;
			for(int p=0;p<X-1;p++) {
				
				rx+=dx[1];
				ry+=dy[1];
			
				if(ry>=N||tempUsed[ry]||map[i+1][j]
						!=map[ry][rx]) {
				
					return false;					
				}				
				tempUsed[ry]=true;
			}
		}
		else {	//오르막 위쪽으로봐 i,j기준
			int rx=j;
			int ry=i;
			if(tempUsed[ry]) return false;
			else tempUsed[ry]=true;
			for(int p=0;p<X-1;p++) {
			
				rx+=dx[0];
				ry+=dy[0];
				if(ry<0||tempUsed[ry]||map[i][j]!=map[ry][rx]) {
				
					return false;					
				}
				tempUsed[ry]=true;
			}
		}
		return true;		
	}
	public static void main(String[] args) throws NumberFormatException, IOException {
		// TODO Auto-generated method stub
		BufferedReader bf=new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st;
		
		int T=Integer.parseInt(bf.readLine());
		for(int z=1;z<=T;z++) {
			
			st= new StringTokenizer(bf.readLine());
			N=Integer.parseInt(st.nextToken());
			X=Integer.parseInt(st.nextToken());
			map=new int[N][N];
			
			for (int i = 0; i <N ; i++) {
	            String []input = bf.readLine().split(" ");
	            for (int j = 0; j <N ; j++) {
	                map[i][j] = Integer.parseInt(input[j]);
	            }
	        }
//			for (int i = 0; i <N ; i++) {
//	            
//	            for (int j = 0; j <N ; j++) {
//	            	System.out.print(map[i][j]+" ");
//	            }System.out.println();
//	        }
			solve();
			System.out.println("#"+z+" "+max);
		}
	}

}
