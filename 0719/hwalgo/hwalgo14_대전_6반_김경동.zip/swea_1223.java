import java.util.Scanner;
import java.util.Stack;

public class swea_1223 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int T = 10;

        for(int test_case = 1; test_case <= T; test_case++) {
            int N = Integer.parseInt(sc.nextLine());
            Stack<Character> s = new Stack<Character>();
            String normal = sc.nextLine();	// 초기 입력연산
            String fixed = null;        	// 후위 연산자 입력을 위한 String 선언

            for(int i =0 ;i<normal.length(); i++) {
                if(normal.charAt(i) != '+' && normal.charAt(i) != '*') fixed += normal.charAt(i);   //숫자인 경우 바로 넣어줌
                else {
                    if(normal.charAt(i) == '*') {    	// *인경우 푸쉬
                        s.push(normal.charAt(i));
                    }else {
                        do {                        
                            if(s.isEmpty()) break;		// 스텍이 비어있을경우 브레이크
                            fixed+= s.pop();			// 빼서 넣기
                        }while(!s.isEmpty() &&s.peek()!= '+');
                        s.push(normal.charAt(i));		//비어있지않고 피크가 +가 아니면 푸쉬
                    }
                }
            }
            while(!s.isEmpty()) {
            	fixed += s.pop();  //빌때까지 fixed에 넣기 		
            }
            // fixed 후위 연산자 생성 완료

            Stack<Integer> cal = new Stack<Integer>();
            for(int i =0; i<fixed.length(); i++) {
                if(fixed.charAt(i) != '+' && fixed.charAt(i) != '*')    
                    cal.push(fixed.charAt(i) - '0'); 

                else {     							
                    int num1 = cal.pop();
                    int num2 = cal.pop();
                    char operator = fixed.charAt(i);
                    switch(operator) {
                        case '*':
                            int times = num1 * num2;
                            cal.push(times);
                            break;
                        case '+':
                            int plus = num1 + num2;
                            cal.push(plus);
                            break;
                    }
                }
            }
            System.out.println("#" + test_case + " " + cal.peek());
        }
    }
}
