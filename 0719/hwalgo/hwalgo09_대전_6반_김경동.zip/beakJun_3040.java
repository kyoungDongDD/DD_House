import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class beakJun_3040 {

	public static void main(String[] args) throws NumberFormatException, IOException {
		// TODO Auto-generated method stub
		BufferedReader bf=new BufferedReader(new InputStreamReader(System.in));
		int[] nanjang=new int[9];
		int sum=0;
		for(int i=0;i<9;i++)	{
			nanjang[i]=Integer.parseInt(bf.readLine());
			sum+=nanjang[i];
		}			
		sum-=100;
		int []bumin=new int[2];
		
		for(int i=0;i<9;i++)	{
			for(int j=0;j<9;j++)	{
				if(i!=j&&sum==(nanjang[i]+nanjang[j])) {					
					bumin[0]=i;
					bumin[1]=j;
				}
				
			}
		}
		for(int i=0;i<9;i++) {
			if(i==bumin[0]||i==bumin[1])
				continue;
			else System.out.println(nanjang[i]);			
		}
	}
}
