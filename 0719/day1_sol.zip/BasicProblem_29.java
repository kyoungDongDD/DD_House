// ##DELETE_FILE:
package com.ssafy.day1;

/**
 * @since 2021. 7. 5.
 */
public class BasicProblem_29 {

    public static void main(String[] args) {

        char C  = 'A';
        
        switch( C ) {
            case 'A' :  // do nothing
                        break;
            case 'B' :  // do nothing
                        break;
            case 65  :  // do nothing
                        break;
        }
    }
}
