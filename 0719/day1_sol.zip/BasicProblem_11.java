package com.ssafy.day1;

/**
 * @since 2021. 7. 4.
 */
public class BasicProblem_11 {
    public static void main(String[] args) {
        // A
        {
            int i = 10;
            byte b = i;
        }
        
        // B
        {
            byte b = 10;
            int i = b;          
        }
    }
}
