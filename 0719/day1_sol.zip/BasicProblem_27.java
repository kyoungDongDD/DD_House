// ##DELETE_FILE:
package com.ssafy.day1;

/**
 * @since 2021. 7. 5.
 */
public class BasicProblem_27 {
    public static void main(String[] args) {
        int I = 3;
        byte B = 3;
        short S = 3;
        char C = 'C';
        double D = 3.0d;
        String str = "STR";
        
        switch( I ) {
            
        }
    }
}
