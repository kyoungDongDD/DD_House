package com.ssafy.day1;

/**
 * @since 2021. 7. 4.
 */
public class BasicProblem_09 {

    public static void main(String[] args) {
        {
            int i = 0;
            System.out.println(i);
        }
        
        System.out.println(i);
    }

}
