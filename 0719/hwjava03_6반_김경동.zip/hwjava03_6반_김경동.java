package com.ssafy.algo;

import java.io.FileInputStream;
import java.util.Scanner;

public class Solution22 {
		
		static int T;		//테스트 수 
				
		public static void main(String[] args) throws Exception{
			
			int [][] deltaUp= {{-3,0},{-2,0},{-1,0}};//상
			int [][] deltaDown= {{3,0},{2,0},{1,0}};//하
			int [][] deltaLeft= {{0,-3},{0,-2},{0,-1}};//좌
			int [][] deltaRight= {{0,3},{0,2},{0,1}};//우
			
			System.setIn(new FileInputStream("input.txt"));	//텍스트파일 가져오기
			Scanner sc = new Scanner(System.in);
			int T = sc.nextInt();							//테스트 횟수 입력
			
			for(int test_case = 1; test_case <= T; test_case++)
			{				
				 int N= sc.nextInt();				//		방길이
				 int numsalt=sc.nextInt(); 			// 		소금쟁이 마릿수
				 int life=numsalt;					// 		초기 살아잇는 소금쟁이수
				 int[][] salty=new int[numsalt][3]; //		소금쟁이 배열				 									
				 boolean[][] spot=new boolean[N][N];//		소금쟁이 존재확인맵				 
				 
				for(int k=0;k<numsalt;k++) {		//      0:x좌표	1:y좌표 2:방향 입력
					for(int l=0; l<3;l++) {
					salty[k][l]=sc.nextInt();					
				    }					
					
					int jumps[][];									//점프 배열생성
		            if(salty[k][2]==1) jumps=deltaUp.clone();		//방향별 점프클론
		            else if(salty[k][2]==2) jumps=deltaDown.clone();
		            else if(salty[k][2]==3) jumps=deltaLeft.clone();
		            else jumps=deltaRight.clone();
		            
		            int nx=salty[k][0];								//	소금쟁이 확인 x좌표에 소금쟁이x값 입력						
		            int ny=salty[k][1];								//	소금쟁이 확인 y좌표에 소금쟁이y값 입력
		            
		            if(spot[nx][ny]==true) {						//	소금쟁이 놓을 시작좌표에 소금쟁이가 있는(true)경우
		               	life--;										//	소금쟁이 죽음 전체 life에서 -1
		            	continue;									//	다른 소금쟁이로 시작
		            }
		            int jump_count=0;								//	점프 카운트 생성
		            for(int[] jump:jumps)							//  int jump배열에 jumps를 넣으면서 돌림
		            {												//  [34번참조] 조건문에서 입력된 jumps가 들어감
		            	
		            nx+=jump[0];									//  [12~15라인 참조] 3,2,1순서로 들어가며 상하좌우 이동
		            ny+=jump[1];
		            
		            if(nx<0||ny<0||nx>=N||ny>=N) 					//	소금쟁이가 맵을 이탈할시 전체 life에서 -1
		            {  
		            	life--;
		            	break;
		            }
		            else if(spot[nx][ny]==true) {					//	소금쟁이가 다른 소금쟁이의 마지막 점프좌표를 밟음
		            												//										전체 life에서 -1
		            	life--;
		            	break;	           
		            }
		            else											//  맵도 안빠져나가고 다른소금쟁이도 안밟았을때
		            	jump_count++;								//  							jump_count+1 >>다음점프
		            if(jump_count==3) {								//	jump_count ==3 >>3번 점프를 마쳤다면
		            	
		            	spot[nx][ny]=true;							//  그지점은 해당 소금쟁이의 좌표(true)가됨
		            }												// 	count==3이 되거나 or 넘어가거나 소금쟁이 밟아서 break된경우
		         }													//다음 소금쟁이 주세요 >>  29라인으로 귀환    		            
		      }
				 System.out.println("#"+test_case+"   "+life);		// 그렇게 계산 해서 test_case번째의 다죽고 남은 소금쟁이수(life출력) 
			}			
		}	
}				