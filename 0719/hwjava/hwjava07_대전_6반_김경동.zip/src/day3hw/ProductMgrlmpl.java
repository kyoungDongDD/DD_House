package day3hw;

import java.util.Arrays;
import java.util.ArrayList;

public class ProductMgrlmpl implements IProductManager{

	

	

		
		ArrayList<Product> pdArray = new ArrayList();
		
		//현재 프로덕트 갯수
		
		ProductMgrlmpl() {}
		private static ProductMgrlmpl instance = new ProductMgrlmpl();
		public static ProductMgrlmpl getInstance() {		
			return instance;
		}
		int Pnum;
		
		public void addProduct(Product pd1) {
			pdArray.add(pd1);
					
		}	
		public void addFrez(Product pd1) {		
			pdArray.add(pd1);
		}
		public void addTV(Product pd1) {		
			pdArray.add(pd1);
		}
		public void list() { // 리스트 봅기
				
				for(Product number: pdArray) {
					System.out.println(number.toString());
				}		
			}
		
				public void list(String num)	{		//검색기능
					int count1=0;
					for(Product number:pdArray) {
						if(number.getNum().equals(num)) {
							System.out.println(number);		
							count1=1;
						}
						if(count1==0) {
							System.out.println("null");
						}
					
					}
					}
					
				public void name_list(String name)	{		//이름부분검색기능
					int count1=0;
					for(Product name1: pdArray) {
						if(name1.getName().indexOf(name)!=-1) {
							count1=1;
							System.out.println(name1);
						}			
					}
					if(count1==0) {
					System.out.println("null");
					}
				}
				
				public void TVlist() {//tv만 검색
					int count1=0;
					for(Product TV1: pdArray) {
						if(TV1.toString().indexOf("TV")!=-1) {
							count1=1;
							System.out.println(TV1);
						}			
					}
					if(count1==0) {
					System.out.println("null");
					}
					
				}
				
				
				
				public void REFlist() {//냉장고만 검색
					int count1=0;
					for(Product RFG: pdArray) {
						if(RFG.toString().indexOf("Refrigerator")!=-1) {
							count1=1;
							
							System.out.println(RFG);
						}			
					}
					if(count1==0) {
					System.out.println("null");
					}
				}
				
				public void fourL() {
					int count1=0;
					
					for(Refrigerator REF : pdArray ) {// 이부분이 해결이 안됨
						if(REF.getVolume()>=400) {
							System.out.println(REF);
							count1=1;
						}
						if(count1==0) {
							System.out.println("null");
							}
					}
				}
				
				public void fiveInch() {
					int count1=0;
					for(TV TV1 : pdArray) {		//이부분이 해결이 안됨
						if(TV1.getInch()>=50) {
							System.out.println(TV1);
							count1=1;
						}
						if(count1==0) {
							System.out.println("null");
							}
					}
					
				}
				
				public void Change(String num,int Price1, int Price2) {
					for(Product prd : pdArray) {
						if(prd.getNum().equals(num)&& prd.getPrice()==Price1) {
							prd.setPrice(Price2);
						}
					}
				}
				
		public void Delete(String num) {	//상품 번호로 지우기 기능 
			
			int pointer=0;
			for(Product number : pdArray) {
			if(number.getNum().equals(num)) { 				
				number=null;
			}
		}
	}
		
		public void priceList(int Price) {
			for(Product price1: pdArray) {
				if(price1.getPrice()<Price) {
					System.out.println(price1.toString());
				}			
			}	
		}
		public void sumPrice()//전체 재고 상품 금액
		{ int sumPrice=0;
			for(Product total: pdArray) {
				sumPrice+=total.getCount()*total.getPrice();			
			}
			System.out.println("Total Price : "+sumPrice+"원 ");
			
		}
		
		
		
		
	}