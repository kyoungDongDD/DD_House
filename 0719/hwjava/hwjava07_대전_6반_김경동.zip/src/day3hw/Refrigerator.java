package day3hw;

public class Refrigerator extends Product {
		
		int Volume;
			
		public Refrigerator() {}
		public Refrigerator(String Num,String Name,int Price,int Count,int Volume) {			
			this.setNum(Num);
			this.setName(Name);
			this.setPrice(Price);
			this.setCount(Count);
			this.Volume=Volume;
			
		}
		public int getVolume() {
			return Volume;
		}
		@Override
		public String toString() {
			return "Refrigerator [Volume=" + Volume + ", Num=" + this.getNum() + ", Name=" + this.getName() + ", Price=" + this.getPrice()
					+ ", Count=" + this.getCount()+ "]";
		}
		
	}

