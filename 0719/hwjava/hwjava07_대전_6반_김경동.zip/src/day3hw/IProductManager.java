package day3hw;

public interface IProductManager {
	
	 void addProduct(Product pd1) ;
	 void addFrez(Product pd1) ;
	 void addTV(Product pd1) ;
	 void list() ;	
	 void list(String num);	
	 void name_list(String name);			
	 void TVlist();		
	 void REFlist() ;
	 void Change(String num,int Price1,int Price2);
	 void Delete(String num);	
	 void priceList(int Price);
	 void sumPrice();
	 void fourL();
	 void fiveInch();
	 
}


