package day3hw;

import java.util.Arrays;
import java.util.Scanner;



public class ProductTest {
	
	public static void main(String[] args) {
		
		ProductMgrlmpl pm1= new ProductMgrlmpl();
		pm1.addProduct(new Product("s154","엘지 청소기",20000,12));
		pm1.addProduct(new Product("fd224","삼성 청소기",46000,12));
		pm1.addProduct(new Product("fd54","중국산 청소기",10000,12));
		pm1.addFrez(new Refrigerator("r873","삼성 비스포크",230000,50,100));
		pm1.addFrez(new Refrigerator("df343","엘지 파워 냉장고",223000,10,100));
		pm1.addTV(new TV("p223","큐올레드TV",4000000,100,20,"QLED"));
		pm1.addTV(new TV("qwe233","오엘이디TV",3200000,120,20,"OLED"));
		
		
		System.out.println("list 출력");
		pm1.list();
		System.out.println("======================================================");
		System.out.println("list 'r873' 출력");
		pm1.list("r873");
		System.out.println("======================================================");
		System.out.println("'p223'삭제 후 list출력");
		pm1.Delete("r873"); //냉장고 삼성 비스포크 삭제
		pm1.list();
		System.out.println("======================================================");
		System.out.println("40000아하 제품 list 출력 ");
		pm1.priceList(40000);
		System.out.println("======================================================");
		pm1.TVlist();//티비만 출력		
		System.out.println("======================================================");
		pm1.sumPrice();		
		System.out.println("======================================================");
		pm1.REFlist();//냉장고만 출력
		System.out.println("======================================================");
		pm1.Change("df343",223000, 100000); // 냉장고 가격변경
		pm1.REFlist();//냉장고만 출력
		/*
		pm1.fiveInch();// 에러 Product 타입에서 Refigerator 타입으로 변환을 못했음
		
		pm1.fourL();//에러
		*/
		
		
		
		
}
}