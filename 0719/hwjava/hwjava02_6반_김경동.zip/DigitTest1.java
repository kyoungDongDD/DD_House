package com.ssafy.algo;

import java.util.Scanner;



public class DigitTest1 {
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		
		int[] ansArr= new int[10];		
		int i;
		
		while(true) {
			i=sc.nextInt();
			if(i==0) { //0이면 스탑!
				break;
			}
				switch(i/10){
					case 0 : ansArr[0]++;
						break;
					case 1 : ansArr[1]++;
						break;
					case 2 : ansArr[2]++;
						break;
					case 3 : ansArr[3]++;
						break;
					case 4 : ansArr[4]++;
						break;
					case 5 : ansArr[5]++;
						break;
					case 6 : ansArr[6]++;
						break;
					case 7 : ansArr[7]++;
						break;
					case 8 : ansArr[8]++;
						break;
					case 9 : ansArr[9]++;
						break;
				}
		}
				
		for(int j=0;j<ansArr.length;j++) {
			if(ansArr[j]!='0') {
				System.out.printf("%d :+%d 개", j,ansArr[j]);
				System.out.println();
			}
		
	}
		}
		

	}


