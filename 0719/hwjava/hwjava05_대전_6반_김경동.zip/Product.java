package day3hw;

public class Product {
	
	private String Num;//제품번호 제품이름 가격 수량
	private String Name;
	private int Price;
	private int Count;
	
	public Product() {}
	
	public Product(String Num,String Name,int Price,int count) {
	this.Num=Num;
	this.Name=Name;
	this.Price=Price;
	this.Count=count;
	
	}
	public String getNum() {
		return Num;		
	}
	public void setNum(String Num) {
		this.Num=Num;
	}
		public String getName() {
		return Name;
	}
		public void setName(String Name) {
			this.Name=Name;
		}

		public int getPrice() {
		return Price;
		}
		public void setPrice(int Price) {
			this.Price=Price;
		}
		public int getCount(){
			return Count;
			}
		public void setCount(int Count) {
			this.Count=Count;
		}
		@Override
		public String toString() {
			return "Product [Num=" + Num + ", Name=" + Name + ", Price=" + Price + ", Count=" + Count + "]";
		}
		
}