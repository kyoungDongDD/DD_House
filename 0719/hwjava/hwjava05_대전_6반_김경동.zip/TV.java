package day3hw;

public class TV extends Product {
	int Inch;
	String Disp_type;

	public TV() {}
	public TV(String Num,String Name,int Price,int Count,int Inch,String Disp_type) {
		this.setNum(Num);
		this.setName(Name);
		this.setPrice(Price);
		this.setCount(Count);
		this.Inch=Inch;
		this.Disp_type=Disp_type;
	}
	@Override
	public String toString() {
		return "TV [Inch=" + Inch + ", Disp_type=" + Disp_type + ", Num=" +this.getNum() + ", Name=" + this.getName() + ", Price=" + this.getPrice()
		+ ", Count=" + this.getCount()+ "]";
	}
	
}
