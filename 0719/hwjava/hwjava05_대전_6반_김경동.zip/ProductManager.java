package day3hw;

import java.util.Arrays;

public class ProductManager {
int max_size=100;
	
	Product[] pdArray = new Product[max_size];
	
	//현재 프로덕트 갯수
	int Pnum;
	
	public void addProduct(Product pd1) {		
		if(Pnum<max_size) {pdArray[Pnum++]=pd1;}		
	}	
	public void addFrez(Product pd1) {		
		if(Pnum<max_size) {pdArray[Pnum++]=pd1;}		
	}
	public void addTV(Product pd1) {		
		if(Pnum<max_size) {pdArray[Pnum++]=pd1;}		
	}
	public void list() { // 리스트 봅기
			
			for(int i=0;i<Pnum;i++) {
				System.out.println(pdArray[i].toString());
			}		
		}
	
			public void list(String num)	{		//검색기능
				int count1=0;
				for(int i =0;i<Pnum;i++) {
					if(pdArray[i].getNum().equals(num)) {
						count1=1;
						System.out.println(pdArray[i]);
					}			
				}
				if(count1==0) {
				System.out.println("null");
				}
			}

	public void Delete(String num) {	//지우기 기능 
		
		int pointer=0;
		for(int i =0;i<Pnum;i++) {
		if(pdArray[i].getNum().equals(num)) { 		
			Pnum--;
			pointer=1;
		}
		if(pointer==1) {
			pdArray[i]=pdArray[i+1];
		}
		}
	}
	
	public void priceList(int Price) {
		for(int i=0;i<Pnum;i++) {
			if(pdArray[i].getPrice()<Price) {
				System.out.println(pdArray[i].toString());
			}
			
			
		}
		
	}
	
	
	
	
	
}
