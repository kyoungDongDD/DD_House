package day3hw;

import java.util.Arrays;
import java.util.Scanner;



public class ProductTest {
	
	public static void main(String[] args) {
		
		ProductManager pm1= new ProductManager();
		pm1.addProduct(new Product("s154","엘지 청소기",20000,12));
		pm1.addProduct(new Product("fd224","삼성 청소기",46000,12));
		pm1.addProduct(new Product("fd54","중국산 청소기",10000,12));
		pm1.addFrez(new Refrigerator("r873","삼성비스포크",230000,50,100));
		pm1.addTV(new TV("p223","큐올레드TV",4000000,100,20,"QLED"));
		
		System.out.println("list 출력");
		pm1.list();
		System.out.println("======================================================");
		System.out.println("list 'r873' 출력");
		pm1.list("r873");
		System.out.println("======================================================");
		System.out.println("'p223'삭제 후 list출력");
		pm1.Delete("r873");
		pm1.list();
		System.out.println("======================================================");
		System.out.println("40000아하 제품 list 출력 ");
		pm1.priceList(40000);
}
}