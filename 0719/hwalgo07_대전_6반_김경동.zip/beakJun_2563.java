import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class beakJun_2563 {

	public static void main(String[] args) throws NumberFormatException, IOException {
		// TODO Auto-generated method stub
		BufferedReader bf= new BufferedReader(new InputStreamReader(System.in));
		int T=Integer.parseInt(bf.readLine());		
		boolean[][] map=new boolean[100][100];
		int result=0;
		for(int i=0;i<T;i++) {
			String[] num=bf.readLine().split(" ");
			for(int p=Integer.parseInt(num[1]); p < Integer.parseInt(num[1])+10 ; p++){
				
				for(int q=Integer.parseInt(num[0]); q < Integer.parseInt(num[0])+10 ; q++) {
					map[q][p]=true;
				}
			}				
		}
		for(int i=0;i<100;i++) {
			for(int j=0;j<100;j++) {
				if(map[i][j]==true) result++;
			}
		}
		System.out.println(result);			
	}
}
